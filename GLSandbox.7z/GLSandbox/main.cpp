#pragma warning(disable:4996)

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <string>
#include <math.h>

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600

#define COLOR_DIFF 0.1

const char *vertexShaderSource = "#version 330 core\n"
"layout (location = 0) in vec3 aPos;\n"
"void main()\n"
"{\n"
"   gl_Position = vec4(aPos.x, aPos.y, aPos.z, 1.0);\n"
"}\0";
char *fragmentShaderSource = "#version 330 core\n"
"out vec4 FragColor;\n"
"void main()\n"
"{\n"
"   FragColor = vec4(0.2f, 0.7f, 0.3f, 1.0f);\n"
"}\n\0";


float r = 1.0f;
float g = 0.0f;
float b = 0.0f;

float vertices[] = {
	-0.5f, -0.5f, 0.0f,
	0.0f, 0.5f, 0.0f,
	0.5f, -0.5f, 0.0f
};

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}


float clampFloat(float value, float min, float max)
{
	if (value < min) return min;
	else if (value > max) return max;
	else return value;
}

void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
	else if (glfwGetKey(window, GLFW_KEY_7) == GLFW_PRESS)
		r = clampFloat(r + 0.1f, 0.0f, 1.0f);
	else if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS)
		r = clampFloat(r - 0.1f, 0.0f, 1.0f);
	else if (glfwGetKey(window, GLFW_KEY_8) == GLFW_PRESS)
		g = clampFloat(g + 0.1f, 0.0f, 1.0f);
	else if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS)
		g = clampFloat(g - 0.1f, 0.0f, 1.0f);
	else if (glfwGetKey(window, GLFW_KEY_9) == GLFW_PRESS)
		b = clampFloat(b + 0.1f, 0.0f, 1.0f);
	else if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS)
		b = clampFloat(b - 0.1f, 0.0f, 1.0f);
}

char defineFragmentShaderColor()
{
	char colorR[10];
	char colorG[10];
	char colorB[10];
	char NewFragmentShaderSource[360] = "#version 330 core\n"
		"out vec4 FragColor;\n"
		"void main()\n"
		"{\n"
		"   FragColor = vec4(";
	sprintf(colorR, "%f", r);
	sprintf(colorG, "%f", g);
	sprintf(colorB, "%f", b);

	strcat(NewFragmentShaderSource, colorR);
	strcat(NewFragmentShaderSource, "f");
	strcat(NewFragmentShaderSource, ",");
	strcat(NewFragmentShaderSource, colorG);
	strcat(NewFragmentShaderSource, "f");
	strcat(NewFragmentShaderSource, ",");
	strcat(NewFragmentShaderSource, colorB);
	strcat(NewFragmentShaderSource, "f");
	strcat(NewFragmentShaderSource, ");\n");
	strcat(NewFragmentShaderSource, "}\n\0");
	return *NewFragmentShaderSource;
}

void createNewShaderProgram(unsigned int &shaderProgram)
{
	unsigned int vertexShader;
	unsigned int fragmentShader;
	int success;
	glDeleteProgram(shaderProgram);

	vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);
	

	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);

	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		char error[512];
		glGetShaderInfoLog(fragmentShader, 512, NULL, error);
		std::cout << "Error compiling FRAGMENT shader:" << std::endl << error << std::endl;
		
		Sleep(500);
	}
	
	shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	glLinkProgram(shaderProgram);

	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

}

int main()
{
	
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	unsigned int VBO;
	unsigned int vertexShader;
	int success;
	unsigned int VAO;

	GLFWwindow* window = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "RE renderer", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to initialize renderer" << std::endl;
		glfwTerminate();
		return -1;
	}

	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "FAILED TO LOAD GLAD" << std::endl;
		Sleep(1500);
		glfwTerminate();
		return -1;
	}


	vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
	glCompileShader(vertexShader);
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		char error[512];
		glGetShaderInfoLog(vertexShader, 512, NULL, error);
		std::cout << "Error compiling shader:" << std::endl << error << std::endl;
		Sleep(500);
		return -1;
	}

	unsigned int fragmentShader;

	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
	glCompileShader(fragmentShader);

	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		char error[512];
		glGetShaderInfoLog(fragmentShader, 512, NULL, error);
		std::cout << "Error compiling shader:" << std::endl << error << std::endl;
		Sleep(500);
		return -1;
	}

	unsigned int shaderProgram;
	shaderProgram = glCreateProgram();

	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	glLinkProgram(shaderProgram);

	glGetShaderiv(shaderProgram, GL_LINK_STATUS, &success);
	if (!success)
	{
		char error[512];
		glGetShaderInfoLog(shaderProgram, 512, NULL, error);
		std::cout << "Error compiling shader:" << std::endl << error << std::endl;
		Sleep(500);
		return -1;
	}



	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);

	glGenBuffers(1, &VBO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	while (!glfwWindowShouldClose(window))
	{
		processInput(window);

		// render code
		glClearColor(0.1f, 0.1f, 0.8f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);
		//createNewShaderProgram(shaderProgram);

		glUseProgram(shaderProgram);
		glBindVertexArray(VAO);
		glDrawArrays(GL_TRIANGLES, 0, 3);
		//

		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	std::cout << " END THE GAME" << std::endl;

	glfwTerminate();
	glDeleteProgram(shaderProgram);

	return 0;
}